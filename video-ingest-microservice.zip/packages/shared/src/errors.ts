export type ErrorCode =
  | "1000_invalid_source_uri"
  | "1001_no_range_support_for_large_remote"
  | "1003_short_probe"
  | "2001_ffprobe_failed"
  | "3001_transcode_failed"
  | "4001_drm_or_restricted_source"
  | "5001_rejected_malware"
  | "9000_manual_inspection_required"
  | "9100_internal_error"
  | "9200_not_found"
  | "9300_validation_failed";

export const ErrorRemediation: Record<ErrorCode, string> = {
  "1000_invalid_source_uri":
    "Verify the source URI and scheme. Supported types: upload, http(s), signed S3-compatible URLs, yt-dlp sources, RTSP/RTMP/UDP streams, zip archives.",
  "1001_no_range_support_for_large_remote":
    "The remote server does not support byte-range requests for a large file. Stage the file to S3 (or upload via chunks) and ingest again using a signed URL.",
  "1003_short_probe":
    "Probe could not determine a usable duration/streams. Verify the file is valid and complete; if it is a stream, ingest it as a stream capture.",
  "2001_ffprobe_failed":
    "ffprobe failed. Try re-uploading, verify the file is not truncated, or run `recipes.sh probe <file>` to reproduce.",
  "3001_transcode_failed":
    "ffmpeg failed during transcode. Download the debug bundle (if present) and reproduce with the command in `recipes.sh` to isolate codec/container issues.",
  "4001_drm_or_restricted_source":
    "The source appears DRM-protected, geo-blocked, or otherwise restricted. Provide an authorized, unrestricted source.",
  "5001_rejected_malware":
    "ClamAV detected malware in the uploaded or fetched content. The content was rejected and should be treated as untrusted.",
  "9000_manual_inspection_required":
    "The job failed repeatedly with safety fallbacks. Manual inspection is required; review debug artifacts and logs.",
  "9100_internal_error": "Unexpected internal error. Retry later; if persistent, escalate to SRE with job id.",
  "9200_not_found": "Resource not found. Verify IDs and access permissions.",
  "9300_validation_failed": "Request validation failed. Correct the request payload and retry."
};

export class AppError extends Error {
  public readonly code: ErrorCode;
  public readonly details?: unknown;
  public readonly remediation: string;

  constructor(code: ErrorCode, message: string, details?: unknown) {
    super(message);
    this.code = code;
    this.details = details;
    this.remediation = ErrorRemediation[code];
  }
}
