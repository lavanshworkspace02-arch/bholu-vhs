import crypto from "node:crypto";
import fs from "node:fs";

export async function sha256File(filePath: string): Promise<string> {
  const hash = crypto.createHash("sha256");
  await new Promise<void>((resolve, reject) => {
    const s = fs.createReadStream(filePath);
    s.on("data", (d) => hash.update(d));
    s.on("error", reject);
    s.on("end", () => resolve());
  });
  return hash.digest("hex");
}

