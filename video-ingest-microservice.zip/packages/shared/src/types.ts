import { z } from "zod";

export const SourceSchema = z.discriminatedUnion("type", [
  z.object({ type: z.literal("upload") }),
  z.object({ type: z.literal("http"), uri: z.string().url() }),
  z.object({ type: z.literal("s3_signed_url"), uri: z.string().url() }),
  z.object({ type: z.literal("yt_dlp"), uri: z.string().min(1) }),
  z.object({
    type: z.literal("stream"),
    uri: z.string().min(1),
    capture_seconds: z.number().int().positive().max(3600).default(30)
  }),
  z.object({ type: z.literal("zip"), uri: z.string().url() })
]);
export type Source = z.infer<typeof SourceSchema>;

export type JobStatus =
  | "queued"
  | "running"
  | "succeeded"
  | "failed"
  | "canceled"
  | "failed_escalation"
  | "rejected_malware"
  | "partial_success";

export type JobPhase = "analyze" | "fetch" | "scan" | "remux" | "transcode" | "package";

export type PlanStep =
  | { kind: "analyze" }
  | { kind: "fetch" }
  | { kind: "scan" }
  | { kind: "remux"; outputExt: "mp4" | "mov" }
  | {
      kind: "transcode";
      videoCodec: "h264" | "hevc" | "prores";
      audioCodec: "aac" | "pcm_s16le";
      width?: number;
      height?: number;
      crf?: number;
      preset?: string;
      useHw?: boolean;
    }
  | { kind: "thumbnail"; format: "jpg" }
  | { kind: "package" };

export type JobPlan = {
  version: 1;
  deterministic: boolean;
  steps: PlanStep[];
  warnings: string[];
};

export type JobProgress = {
  phase: JobPhase | null;
  progress: number; // 0..100
  message?: string;
};

