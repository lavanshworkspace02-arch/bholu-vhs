import fs from "node:fs";
import path from "node:path";
import { z } from "zod";

export const ProfileSchema = z.object({
  description: z.string(),
  container: z.enum(["mp4", "mov"]),
  video: z.object({
    codec: z.enum(["h264", "hevc", "prores"]),
    width: z.number().int().positive().optional(),
    height: z.number().int().positive().optional(),
    crf: z.number().int().min(0).max(51).optional(),
    preset: z.string().optional(),
    profile: z.string().optional()
  }),
  audio: z.object({
    codec: z.enum(["aac", "pcm_s16le"]),
    bitrate_kbps: z.number().int().positive().optional()
  }),
  allow_remux_if_compatible: z.boolean(),
  deterministic: z.boolean()
});

export const PolicySchema = z.object({
  version: z.number().int(),
  profiles: z.record(ProfileSchema)
});

export type Policy = z.infer<typeof PolicySchema>;
export type Profile = z.infer<typeof ProfileSchema>;

export function loadPolicy(repoRoot: string): Policy {
  const p = path.join(repoRoot, "policy.json");
  const raw = fs.readFileSync(p, "utf8");
  return PolicySchema.parse(JSON.parse(raw));
}

