import { AppError } from "@video/shared";
import type { JobPlan, Profile } from "@video/shared";

type FfprobeJson = {
  format?: { format_name?: string; duration?: string };
  streams?: Array<{ codec_type?: string; codec_name?: string }>;
};

function isMp4CompatibleVideo(codec?: string) {
  return codec === "h264" || codec === "hevc" || codec === "av1" || codec === "mpeg4";
}
function isMp4CompatibleAudio(codec?: string) {
  return codec === "aac" || codec === "mp3" || codec === "ac3" || codec === "eac3" || codec === "alac";
}

export function buildPlanFromProbe(probe: FfprobeJson, profile: Profile, opts: { workerGpu: boolean }): JobPlan {
  const warnings: string[] = [];
  const duration = probe.format?.duration ? Number(probe.format.duration) : NaN;
  if (!Number.isFinite(duration) || duration <= 0) {
    throw new AppError("1003_short_probe", "Probe did not report duration.", { duration: probe.format?.duration });
  }

  const video = probe.streams?.find((s) => s.codec_type === "video");
  const audio = probe.streams?.find((s) => s.codec_type === "audio");
  const unknownStreams = (probe.streams ?? []).filter((s) => s.codec_type && s.codec_type !== "video" && s.codec_type !== "audio");
  if (unknownStreams.length > 0) warnings.push(`Stripping ${unknownStreams.length} non A/V stream(s) (subtitles/data).`);

  const steps: JobPlan["steps"] = [{ kind: "analyze" }, { kind: "fetch" }, { kind: "scan" }];

  const wantsMp4 = profile.container === "mp4";
  const srcVideoCodec = video?.codec_name;
  const srcAudioCodec = audio?.codec_name;

  const remuxCompatible =
    profile.allow_remux_if_compatible &&
    wantsMp4 &&
    isMp4CompatibleVideo(srcVideoCodec) &&
    (srcAudioCodec ? isMp4CompatibleAudio(srcAudioCodec) : true);

  if (remuxCompatible) {
    steps.push({ kind: "remux", outputExt: "mp4" });
  } else {
    const useHw = opts.workerGpu && (profile.video.codec === "h264" || profile.video.codec === "hevc");
    if (useHw) warnings.push("Using hardware-accelerated encode on GPU worker.");
    steps.push({
      kind: "transcode",
      videoCodec: profile.video.codec,
      audioCodec: profile.audio.codec,
      width: profile.video.width,
      height: profile.video.height,
      crf: profile.video.crf,
      preset: profile.video.preset,
      useHw
    });
  }

  steps.push({ kind: "thumbnail", format: "jpg" });
  steps.push({ kind: "package" });

  return { version: 1, deterministic: profile.deterministic, steps, warnings };
}
