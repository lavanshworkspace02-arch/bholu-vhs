import { buildPlanFromProbe } from "./plan";

const profileWeb = {
  description: "web",
  container: "mp4" as const,
  video: { codec: "h264" as const, width: 1280, height: 720, crf: 23, preset: "medium" },
  audio: { codec: "aac" as const, bitrate_kbps: 128 },
  allow_remux_if_compatible: true,
  deterministic: true
};

test("buildPlanFromProbe chooses remux when MP4-compatible codecs", () => {
  const probe = {
    format: { duration: "10.0" },
    streams: [
      { codec_type: "video", codec_name: "h264" },
      { codec_type: "audio", codec_name: "aac" }
    ]
  };
  const plan = buildPlanFromProbe(probe, profileWeb as any, { workerGpu: false });
  expect(plan.steps.some((s) => s.kind === "remux")).toBe(true);
  expect(plan.steps.some((s) => s.kind === "transcode")).toBe(false);
});

test("buildPlanFromProbe chooses transcode when incompatible audio", () => {
  const probe = {
    format: { duration: "10.0" },
    streams: [
      { codec_type: "video", codec_name: "h264" },
      { codec_type: "audio", codec_name: "opus" }
    ]
  };
  const plan = buildPlanFromProbe(probe, profileWeb as any, { workerGpu: false });
  expect(plan.steps.some((s) => s.kind === "transcode")).toBe(true);
});

