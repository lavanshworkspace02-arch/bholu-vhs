import { spawn } from "node:child_process";
import fs from "node:fs";

export type ExecResult = {
  exitCode: number | null;
  stdout: string;
  stderr: string;
};

export async function execLimited(
  cmd: string,
  args: string[],
  opts?: { cwd?: string; env?: NodeJS.ProcessEnv; maxOutputBytes?: number; logFilePath?: string }
): Promise<ExecResult> {
  const max = opts?.maxOutputBytes ?? 200_000; // 200KB tail for API/debug attachment
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, { cwd: opts?.cwd, env: opts?.env, stdio: ["ignore", "pipe", "pipe"] });
    let stdoutTail = Buffer.alloc(0);
    let stderrTail = Buffer.alloc(0);
    const logStream = opts?.logFilePath
      ? fs.createWriteStream(opts.logFilePath, { flags: "a" })
      : null;
    child.stdout.on("data", (d: Buffer) => {
      if (logStream) logStream.write(d);
      stdoutTail = Buffer.concat([stdoutTail, d]);
      if (stdoutTail.length > max) stdoutTail = stdoutTail.subarray(stdoutTail.length - max);
    });
    child.stderr.on("data", (d: Buffer) => {
      if (logStream) logStream.write(d);
      stderrTail = Buffer.concat([stderrTail, d]);
      if (stderrTail.length > max) stderrTail = stderrTail.subarray(stderrTail.length - max);
    });
    child.on("error", reject);
    child.on("close", (code) => {
      if (logStream) logStream.end();
      resolve({ exitCode: code, stdout: stdoutTail.toString("utf8"), stderr: stderrTail.toString("utf8") });
    });
  });
}
