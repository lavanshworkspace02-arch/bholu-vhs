import { execLimited } from "./exec";

export async function ffprobeFast(filePath: string) {
  const args = [
    "-v",
    "error",
    "-print_format",
    "json",
    "-show_format",
    "-show_streams",
    "-read_intervals",
    "%+#5",
    filePath
  ];
  const res = await execLimited("ffprobe", args, { maxOutputBytes: 200_000 });
  return res;
}
