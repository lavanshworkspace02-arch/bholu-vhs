import { Client } from "minio";
import fs from "node:fs";

export type S3Config = {
  endPoint: string;
  region: string;
  accessKey: string;
  secretKey: string;
  bucket: string;
  useSSL?: boolean;
};

function parseEndpoint(endpoint: string) {
  const u = new URL(endpoint);
  return { host: u.hostname, port: Number(u.port || (u.protocol === "https:" ? 443 : 80)), useSSL: u.protocol === "https:" };
}

export function createS3(cfg: S3Config) {
  const ep = parseEndpoint(cfg.endPoint);
  const client = new Client({
    endPoint: ep.host,
    port: ep.port,
    useSSL: ep.useSSL,
    accessKey: cfg.accessKey,
    secretKey: cfg.secretKey,
    region: cfg.region
  });

  async function ensureBucket() {
    const exists = await client.bucketExists(cfg.bucket).catch(() => false);
    if (!exists) await client.makeBucket(cfg.bucket, cfg.region);
  }

  async function putFile(opts: { key: string; filePath: string; contentType: string }) {
    await ensureBucket();
    const stat = fs.statSync(opts.filePath);
    await client.fPutObject(cfg.bucket, opts.key, opts.filePath, { "Content-Type": opts.contentType });
    return { bytes: BigInt(stat.size) };
  }

  async function presignGetObject(key: string, ttlSeconds: number) {
    const ttl = Math.min(ttlSeconds, 24 * 60 * 60);
    return client.presignedGetObject(cfg.bucket, key, ttl);
  }

  return { client, ensureBucket, putFile, presignGetObject, bucket: cfg.bucket };
}

