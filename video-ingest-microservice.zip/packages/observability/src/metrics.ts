import client from "prom-client";

export function createRegistry(serviceName: string) {
  const registry = new client.Registry();
  client.collectDefaultMetrics({ register: registry, prefix: `${serviceName}_` });
  return registry;
}

export function createWorkerMetrics(registry: client.Registry) {
  const jobsTotal = new client.Counter({
    name: "jobs_total",
    help: "Total jobs processed",
    labelNames: ["status"] as const,
    registers: [registry]
  });
  const jobsFailed = new client.Counter({
    name: "jobs_failed",
    help: "Total failed jobs",
    registers: [registry]
  });
  const jobsSuccess = new client.Counter({
    name: "jobs_success",
    help: "Total succeeded jobs",
    registers: [registry]
  });
  const avgTranscodeTime = new client.Histogram({
    name: "avg_transcode_time_seconds",
    help: "Transcode time seconds",
    buckets: [1, 5, 10, 30, 60, 120, 300, 600],
    registers: [registry]
  });
  const ffmpegErrorCodesTotal = new client.Counter({
    name: "ffmpeg_error_codes_total",
    help: "Counts of ffmpeg exit codes",
    labelNames: ["code"] as const,
    registers: [registry]
  });
  const workerMemoryBytes = new client.Gauge({
    name: "worker_memory_bytes",
    help: "Worker process memory (rss) bytes",
    registers: [registry]
  });
  return { jobsTotal, jobsFailed, jobsSuccess, avgTranscodeTime, ffmpegErrorCodesTotal, workerMemoryBytes };
}
