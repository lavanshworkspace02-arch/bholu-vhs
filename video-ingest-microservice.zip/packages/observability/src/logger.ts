import pino from "pino";

export type LogContext = {
  service: string;
};

export function createLogger(ctx: LogContext) {
  return pino({
    level: process.env.LOG_LEVEL ?? "info",
    base: { service: ctx.service },
    redact: {
      paths: ["req.headers.authorization", "authorization", "password", "token"],
      censor: "[REDACTED]"
    }
  });
}

