import { diag, DiagConsoleLogger, DiagLogLevel } from "@opentelemetry/api";
import { OTLPTraceExporter } from "@opentelemetry/exporter-trace-otlp-grpc";
import { OTLPMetricExporter } from "@opentelemetry/exporter-metrics-otlp-grpc";
import { Resource } from "@opentelemetry/resources";
import { MeterProvider, PeriodicExportingMetricReader } from "@opentelemetry/sdk-metrics";
import { NodeSDK } from "@opentelemetry/sdk-node";
import { SemanticResourceAttributes } from "@opentelemetry/semantic-conventions";
import { getNodeAutoInstrumentations } from "@opentelemetry/auto-instrumentations-node";

export async function initOtel(serviceName: string) {
  if (process.env.OTEL_DISABLED === "true") return;

  diag.setLogger(new DiagConsoleLogger(), DiagLogLevel.ERROR);

  const endpoint = process.env.OTEL_EXPORTER_OTLP_ENDPOINT;
  const traceExporter = endpoint ? new OTLPTraceExporter({ url: endpoint }) : undefined;
  const metricExporter = endpoint ? new OTLPMetricExporter({ url: endpoint }) : undefined;

  const resource = new Resource({
    [SemanticResourceAttributes.SERVICE_NAME]: serviceName
  });

  const metricReader =
    metricExporter &&
    new PeriodicExportingMetricReader({
      exporter: metricExporter,
      exportIntervalMillis: 5000
    });

  const meterProvider = new MeterProvider({ resource });
  if (metricReader) meterProvider.addMetricReader(metricReader);

  const sdk = new NodeSDK({
    resource,
    traceExporter,
    instrumentations: [getNodeAutoInstrumentations()],
    meterProvider
  });

  await sdk.start();

  process.on("SIGTERM", () => {
    void sdk.shutdown();
  });
}

