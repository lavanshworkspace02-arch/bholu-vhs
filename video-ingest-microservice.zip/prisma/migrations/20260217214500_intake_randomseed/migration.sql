ALTER TABLE "IntakeSession" ADD COLUMN "randomSeed" text NULL;

