-- Initial schema for video-ingest-microservice

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE TABLE "User" (
  "id" text PRIMARY KEY DEFAULT (gen_random_uuid()::text),
  "email" text NOT NULL UNIQUE,
  "createdAt" timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE "Project" (
  "id" text PRIMARY KEY DEFAULT (gen_random_uuid()::text),
  "name" text NOT NULL,
  "ownerId" text NOT NULL REFERENCES "User"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  "createdAt" timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX "Project_ownerId_idx" ON "Project"("ownerId");

CREATE TABLE "IntakeSession" (
  "id" text PRIMARY KEY DEFAULT (gen_random_uuid()::text),
  "projectId" text NOT NULL REFERENCES "Project"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  "status" text NOT NULL,
  "profile" text NOT NULL,
  "sourceJson" jsonb NOT NULL,
  "uploadPath" text NULL,
  "uploadedBytes" bigint NOT NULL DEFAULT 0,
  "totalBytes" bigint NULL,
  "createdAt" timestamptz NOT NULL DEFAULT now(),
  "updatedAt" timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX "IntakeSession_projectId_idx" ON "IntakeSession"("projectId");

CREATE TABLE "Job" (
  "id" text PRIMARY KEY DEFAULT (gen_random_uuid()::text),
  "projectId" text NOT NULL REFERENCES "Project"("id") ON DELETE RESTRICT ON UPDATE CASCADE,
  "status" text NOT NULL,
  "phase" text NULL,
  "progress" integer NOT NULL DEFAULT 0,
  "profile" text NOT NULL,
  "randomSeed" text NULL,
  "sourceJson" jsonb NOT NULL,
  "planJson" jsonb NULL,
  "warningsJson" jsonb NULL,
  "errorCode" text NULL,
  "errorMessage" text NULL,
  "errorDetails" jsonb NULL,
  "ffmpegExitCode" integer NULL,
  "retryCount" integer NOT NULL DEFAULT 0,
  "createdAt" timestamptz NOT NULL DEFAULT now(),
  "updatedAt" timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX "Job_projectId_idx" ON "Job"("projectId");
CREATE INDEX "Job_status_idx" ON "Job"("status");

CREATE TABLE "Artifact" (
  "id" text PRIMARY KEY DEFAULT (gen_random_uuid()::text),
  "jobId" text NOT NULL REFERENCES "Job"("id") ON DELETE CASCADE ON UPDATE CASCADE,
  "kind" text NOT NULL,
  "bucket" text NOT NULL,
  "key" text NOT NULL,
  "contentType" text NOT NULL,
  "bytes" bigint NOT NULL,
  "sha256" text NOT NULL,
  "createdAt" timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX "Artifact_jobId_idx" ON "Artifact"("jobId");
