import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const API = process.env.API_URL ?? "http://localhost:8080";
const PROFILE = process.env.PROFILE ?? "web_720p_h264";

async function createSyntheticMp4(outPath: string) {
  // Generate a tiny input using ffmpeg if available; else fail fast with a clear message.
  const { spawn } = await import("node:child_process");
  await new Promise<void>((resolve, reject) => {
    const child = spawn("ffmpeg", ["-hide_banner", "-y", "-f", "lavfi", "-i", "testsrc=size=320x240:rate=30", "-t", "2", "-c:v", "libx264", "-pix_fmt", "yuv420p", outPath], {
      stdio: "ignore"
    });
    child.on("error", reject);
    child.on("close", (code) => (code === 0 ? resolve() : reject(new Error(`ffmpeg exited ${code}`))));
  });
}

function chunks(buf: Buffer, size: number) {
  const out: Buffer[] = [];
  for (let i = 0; i < buf.length; i += size) out.push(buf.subarray(i, Math.min(buf.length, i + size)));
  return out;
}

async function uploadViaSession(filePath: string) {
  const create = await fetch(`${API}/api/v1/sessions`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ profile: PROFILE, source: { type: "upload" } })
  });
  const session = await create.json();
  const id = session.id as string;

  const buf = fs.readFileSync(filePath);
  const parts = chunks(buf, 64 * 1024);
  let offset = 0;
  for (let i = 0; i < parts.length; i++) {
    const part = parts[i];
    const start = offset;
    const end = offset + part.length - 1;
    const r = await fetch(`${API}/api/v1/sessions/${id}/upload_chunk`, {
      method: "POST",
      headers: {
        "content-type": "application/octet-stream",
        "content-range": `bytes ${start}-${end}/${buf.length}`
      },
      body: part
    });
    if (!r.ok) throw new Error(`upload_chunk failed: ${r.status} ${await r.text()}`);
    offset += part.length;
  }

  const commit = await fetch(`${API}/api/v1/sessions/${id}/commit`, { method: "POST" });
  const commitJson = await commit.json();
  return commitJson.job_id as string;
}

async function poll(jobId: string) {
  for (;;) {
    const r = await fetch(`${API}/api/v1/jobs/${jobId}/status`);
    const s = await r.json();
    if (s.status === "succeeded" || s.status === "failed" || s.status === "failed_escalation" || s.status === "canceled") return s;
    await new Promise((r2) => setTimeout(r2, 500));
  }
}

async function main() {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "video-jobs-"));
  const input = path.join(tmp, "in.mp4");
  await createSyntheticMp4(input);

  const concurrency = Number(process.env.CONCURRENCY ?? 100);
  const start = Date.now();
  const jobIds = await Promise.all(Array.from({ length: concurrency }, () => uploadViaSession(input)));
  const results = await Promise.all(jobIds.map((id) => poll(id)));
  const ok = results.filter((r) => r.status === "succeeded").length;
  console.log(JSON.stringify({ total: results.length, ok, duration_ms: Date.now() - start }, null, 2));
}

void main();

