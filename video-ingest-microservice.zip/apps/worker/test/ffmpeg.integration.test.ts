import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import crypto from "node:crypto";
import { spawnSync } from "node:child_process";

function hasCmd(cmd: string) {
  const r = spawnSync("sh", ["-lc", `command -v ${cmd}`], { encoding: "utf8" });
  return r.status === 0;
}

function sha256(p: string) {
  const h = crypto.createHash("sha256");
  h.update(fs.readFileSync(p));
  return h.digest("hex");
}

function run(cmd: string, args: string[]) {
  const r = spawnSync(cmd, args, { encoding: "utf8" });
  if (r.status !== 0) {
    throw new Error(`${cmd} failed (${r.status})\n${r.stderr}`);
  }
  return r;
}

function ffprobeJson(file: string) {
  const r = run("ffprobe", ["-v", "error", "-print_format", "json", "-show_format", "-show_streams", file]);
  return JSON.parse(r.stdout);
}

const itIf = (cond: boolean) => (cond ? it : it.skip);

describe("ffmpeg integration", () => {
  const ok = hasCmd("ffmpeg") && hasCmd("ffprobe");
  const hasZip = hasCmd("zip") && hasCmd("unzip");
  const runStreams = process.env.RUN_STREAM_TESTS === "true";
  itIf(ok)("remux preserves h264/aac", () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "video-it-"));
    const inMp4 = path.join(dir, "in.mp4");
    const rotated = path.join(dir, "rotated.mp4");
    const outMp4 = path.join(dir, "out.mp4");

    run("ffmpeg", ["-hide_banner", "-y", "-f", "lavfi", "-i", "testsrc=size=320x240:rate=30", "-t", "2", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-c:a", "aac", "-f", "mp4", inMp4]);
    run("ffmpeg", ["-hide_banner", "-y", "-i", inMp4, "-c", "copy", "-metadata:s:v:0", "rotate=90", rotated]);
    run("ffmpeg", ["-hide_banner", "-y", "-i", rotated, "-map", "0", "-c", "copy", "-movflags", "+faststart", outMp4]);

    const p = ffprobeJson(outMp4);
    const v = p.streams.find((s: any) => s.codec_type === "video");
    const a = p.streams.find((s: any) => s.codec_type === "audio");
    expect(v.codec_name).toBe("h264");
    expect(a.codec_name).toBe("aac");
  });

  itIf(ok)("MOV(ProRes) transcodes to web h264", () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "video-it-"));
    const prores = path.join(dir, "in.mov");
    const outMp4 = path.join(dir, "out.mp4");
    run("ffmpeg", [
      "-hide_banner",
      "-y",
      "-f",
      "lavfi",
      "-i",
      "testsrc=size=320x240:rate=30",
      "-t",
      "2",
      "-c:v",
      "prores_ks",
      "-profile:v",
      "3",
      "-c:a",
      "pcm_s16le",
      prores
    ]);
    run("ffmpeg", ["-hide_banner", "-y", "-i", prores, "-c:v", "libx264", "-crf", "23", "-preset", "medium", "-threads", "1", "-c:a", "aac", "-b:a", "128k", outMp4]);
    const p = ffprobeJson(outMp4);
    const v = p.streams.find((s: any) => s.codec_type === "video");
    expect(v.codec_name).toBe("h264");
  });

  itIf(ok)("MKV(HEVC) probes and can remux to MP4 when compatible", () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "video-it-"));
    const mkv = path.join(dir, "in.mkv");
    const mp4 = path.join(dir, "out.mp4");
    const enc = spawnSync("ffmpeg", ["-hide_banner", "-y", "-f", "lavfi", "-i", "testsrc=size=160x120:rate=30", "-t", "1", "-c:v", "libx265", mkv], { encoding: "utf8" });
    if (enc.status !== 0) return; // encoder may not be present; treat as skipped semantics
    run("ffmpeg", ["-hide_banner", "-y", "-i", mkv, "-map", "0", "-c", "copy", "-movflags", "+faststart", mp4]);
    const p = ffprobeJson(mp4);
    const v = p.streams.find((s: any) => s.codec_type === "video");
    expect(v.codec_name).toBe("hevc");
  });

  itIf(ok)("transcode is deterministic with threads=1", () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "video-it-"));
    const input = path.join(dir, "in.mp4");
    const out1 = path.join(dir, "out1.mp4");
    const out2 = path.join(dir, "out2.mp4");

    run("ffmpeg", ["-hide_banner", "-y", "-f", "lavfi", "-i", "testsrc=size=320x240:rate=30", "-t", "2", "-c:v", "libx264", "-pix_fmt", "yuv420p", input]);

    const args = (out: string) => [
      "-hide_banner",
      "-y",
      "-i",
      input,
      "-map",
      "0:v:0",
      "-map",
      "0:a?",
      "-vf",
      "scale=320:240,format=yuv420p",
      "-c:v",
      "libx264",
      "-preset",
      "medium",
      "-crf",
      "23",
      "-threads",
      "1",
      "-fflags",
      "+bitexact",
      "-flags:v",
      "+bitexact",
      "-flags:a",
      "+bitexact",
      "-movflags",
      "+faststart",
      out
    ];

    run("ffmpeg", args(out1));
    run("ffmpeg", args(out2));

    expect(sha256(out1)).toBe(sha256(out2));
  });

  itIf(ok && hasZip)("ZIP with multiple files extracts", () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "video-it-"));
    const a = path.join(dir, "a.mp4");
    const b = path.join(dir, "b.mp4");
    run("ffmpeg", ["-hide_banner", "-y", "-f", "lavfi", "-i", "testsrc=size=160x120:rate=30", "-t", "1", "-c:v", "libx264", "-pix_fmt", "yuv420p", a]);
    run("ffmpeg", ["-hide_banner", "-y", "-f", "lavfi", "-i", "testsrc=size=160x120:rate=30", "-t", "1", "-c:v", "libx264", "-pix_fmt", "yuv420p", b]);
    const zipPath = path.join(dir, "inputs.zip");
    run("zip", ["-j", zipPath, a, b]);
    const outDir = path.join(dir, "unz");
    run("unzip", ["-o", zipPath, "-d", outDir]);
    const files = fs.readdirSync(outDir).filter((f) => f.endsWith(".mp4"));
    expect(files.sort()).toEqual(["a.mp4", "b.mp4"]);
  });

  itIf(ok)("thumbnail exists and non-empty", () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "video-it-"));
    const input = path.join(dir, "in.mp4");
    const thumb = path.join(dir, "thumb.jpg");
    run("ffmpeg", ["-hide_banner", "-y", "-f", "lavfi", "-i", "testsrc=size=320x240:rate=30", "-t", "2", "-c:v", "libx264", "-pix_fmt", "yuv420p", input]);
    run("ffmpeg", ["-hide_banner", "-y", "-ss", "00:00:01.000", "-i", input, "-frames:v", "1", "-vf", "scale=320:-2:flags=bicubic", thumb]);
    expect(fs.statSync(thumb).size).toBeGreaterThan(0);
  });

  (runStreams ? it : it.skip)("RTSP intermittent stream (manual env) - placeholder", () => {
    // This test is intentionally opt-in because it requires a real RTSP endpoint.
    // Set RUN_STREAM_TESTS=true and RTSP_URI=... to enable.
    const uri = process.env.RTSP_URI;
    if (!uri) throw new Error("RTSP_URI is required when RUN_STREAM_TESTS=true");
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "video-it-"));
    const out = path.join(dir, "capture.mp4");
    run("ffmpeg", ["-hide_banner", "-y", "-rtsp_transport", "tcp", "-i", uri, "-t", "5", "-c:v", "libx264", "-c:a", "aac", out]);
    expect(fs.statSync(out).size).toBeGreaterThan(0);
  });
});
