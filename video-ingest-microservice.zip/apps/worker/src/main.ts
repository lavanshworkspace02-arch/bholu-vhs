import "dotenv/config";
import http from "node:http";
import path from "node:path";
import { Worker } from "bullmq";
import { initOtel, createLogger, createRegistry, createWorkerMetrics } from "@video/observability";
import { prisma } from "@video/db";
import { processJob } from "./processor";

async function start() {
  await initOtel("worker");
  const logger = createLogger({ service: "worker" });

  const registry = createRegistry("worker");
  const metrics = createWorkerMetrics(registry);
  setInterval(() => {
    metrics.workerMemoryBytes.set(process.memoryUsage().rss);
  }, 5000).unref();

  const server = http.createServer(async (req, res) => {
    if (req.url === "/metrics") {
      res.setHeader("Content-Type", registry.contentType);
      res.end(await registry.metrics());
      return;
    }
    res.statusCode = 404;
    res.end("not found");
  });
  server.listen(9091, "0.0.0.0");

  const connection = { url: process.env.REDIS_URL ?? "redis://localhost:6379" };
  const workerGpu = process.env.WORKER_GPU === "true";

  const w = new Worker(
    "ingest",
    async (bullJob) => {
      const jobId = (bullJob.data as any).jobId as string;
      const attempt = bullJob.attemptsMade + 1;
      return processJob({
        jobId,
        attempt,
        workerGpu,
        repoRoot: path.resolve(__dirname, "../../../"),
        prisma: prisma(),
        logger,
        metrics
      });
    },
    { connection, concurrency: 2 }
  );

  w.on("completed", (j) => logger.info({ jobId: j.id }, "job_completed"));
  w.on("failed", (j, err) => logger.error({ jobId: j?.id, err }, "job_failed"));

  logger.info({ workerGpu }, "worker_started");
}

void start();
