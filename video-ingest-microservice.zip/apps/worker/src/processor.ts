import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import stream from "node:stream";
import { pipeline } from "node:stream/promises";
import { execLimited } from "@video/ffmpeg";
import { ffprobeFast } from "@video/ffmpeg";
import { buildPlanFromProbe } from "@video/ffmpeg";
import { loadPolicy, AppError, sha256File } from "@video/shared";
import type { PrismaClient } from "@prisma/client";
import type { Logger } from "pino";
import { createS3 } from "@video/storage";
import { Queue } from "bullmq";

type Metrics = ReturnType<typeof import("@video/observability").createWorkerMetrics>;

type Ctx = {
  jobId: string;
  attempt: number;
  workerGpu: boolean;
  repoRoot: string;
  prisma: PrismaClient;
  logger: Logger;
  metrics: Metrics;
};

function workDir(repoRoot: string, jobId: string) {
  return path.join(repoRoot, "data", "work", jobId);
}

function shouldSample(jobId: string, rate: number) {
  if (!(rate > 0 && rate <= 1)) return false;
  const h = crypto.createHash("sha256").update(jobId).digest();
  const n = h.readUInt32BE(0);
  return n / 0xffffffff < rate;
}

async function setJob(prisma: PrismaClient, jobId: string, data: any) {
  await prisma.job.update({ where: { id: jobId }, data });
}

async function isCanceled(prisma: PrismaClient, jobId: string) {
  const j = await prisma.job.findUnique({ where: { id: jobId }, select: { status: true } });
  return j?.status === "canceled";
}

async function downloadToFile(uri: string, outPath: string, sizeLimitBytes?: number) {
  const head = await fetch(uri, { method: "HEAD" }).catch(() => null);
  const len = head?.headers.get("content-length");
  const acceptRanges = head?.headers.get("accept-ranges")?.toLowerCase() === "bytes";
  const size = len ? Number(len) : null;
  if (sizeLimitBytes && size && size > sizeLimitBytes && !acceptRanges) {
    throw new AppError("1001_no_range_support_for_large_remote", "Remote server lacks byte ranges for large file", { size, accept_ranges: acceptRanges });
  }
  const res = await fetch(uri);
  if (!res.ok || !res.body) throw new AppError("1000_invalid_source_uri", "Failed to fetch remote source", { status: res.status });
  fs.mkdirSync(path.dirname(outPath), { recursive: true });
  const f = fs.createWriteStream(outPath);
  await pipeline(stream.Readable.fromWeb(res.body as any), f);
}

async function clamavScan(filePath: string, logFilePath?: string) {
  const host = process.env.CLAMAV_HOST ?? "localhost";
  const port = process.env.CLAMAV_PORT ?? "3310";
  const res = await execLimited("clamdscan", ["--no-summary", "--tcp", "--host", host, "--port", port, filePath], { maxOutputBytes: 200_000, logFilePath });
  // clamdscan exit codes: 0 ok, 1 infected, 2 error
  if (res.exitCode === 1) throw new AppError("5001_rejected_malware", "Malware detected", { output: res.stdout, stderr: res.stderr });
  if (res.exitCode !== 0) throw new AppError("9100_internal_error", "ClamAV scan failed", res);
}

function isZipFile(filePath: string) {
  const fd = fs.openSync(filePath, "r");
  try {
    const b = Buffer.alloc(4);
    fs.readSync(fd, b, 0, 4, 0);
    return b[0] === 0x50 && b[1] === 0x4b && (b[2] === 0x03 || b[2] === 0x05 || b[2] === 0x07) && (b[3] === 0x04 || b[3] === 0x06 || b[3] === 0x08);
  } finally {
    fs.closeSync(fd);
  }
}

async function ffmpegRemux(input: string, output: string, logFilePath?: string) {
  return execLimited(
    "ffmpeg",
    ["-hide_banner", "-y", "-i", input, "-map", "0", "-c", "copy", "-movflags", "+faststart", "-map_metadata", "0", "-map_chapters", "0", output],
    { maxOutputBytes: 200_000, logFilePath }
  );
}

async function ffmpegTranscode(
  input: string,
  output: string,
  opts: { profile: any; useHw: boolean; deterministic: boolean; logFilePath?: string }
) {
  const detArgs = opts.deterministic ? ["-fflags", "+bitexact", "-flags:v", "+bitexact", "-flags:a", "+bitexact", "-threads", "1"] : [];

  if (opts.useHw && opts.profile.video.codec === "h264") {
    return execLimited(
      "ffmpeg",
      [
        "-hide_banner",
        "-y",
        "-hwaccel",
        "cuda",
        "-i",
        input,
        "-map",
        "0:v:0",
        "-map",
        "0:a?",
        "-map",
        "-0:d?",
        "-map",
        "-0:s?",
        "-vf",
        `scale=w=${opts.profile.video.width ?? 1280}:h=${opts.profile.video.height ?? 720}:force_original_aspect_ratio=decrease,pad=${opts.profile.video.width ?? 1280}:${opts.profile.video.height ?? 720}:(ow-iw)/2:(oh-ih)/2,format=yuv420p`,
        "-c:v",
        "h264_nvenc",
        "-preset",
        "p4",
        "-cq",
        String(opts.profile.video.crf ?? 23),
        "-c:a",
        "aac",
        "-b:a",
        `${opts.profile.audio.bitrate_kbps ?? 128}k`,
        "-movflags",
        "+faststart",
        "-map_metadata",
        "0",
        "-map_chapters",
        "0",
        ...detArgs,
        output
      ],
      { maxOutputBytes: 200_000, logFilePath: opts.logFilePath }
    );
  }

  if (opts.profile.video.codec === "h264") {
    return execLimited(
      "ffmpeg",
      [
        "-hide_banner",
        "-y",
        "-i",
        input,
        "-map",
        "0:v:0",
        "-map",
        "0:a?",
        "-map",
        "-0:d?",
        "-map",
        "-0:s?",
        "-vf",
        `scale=w=${opts.profile.video.width ?? 1280}:h=${opts.profile.video.height ?? 720}:force_original_aspect_ratio=decrease,pad=${opts.profile.video.width ?? 1280}:${opts.profile.video.height ?? 720}:(ow-iw)/2:(oh-ih)/2,format=yuv420p`,
        "-c:v",
        "libx264",
        "-preset",
        opts.profile.video.preset ?? "medium",
        "-crf",
        String(opts.profile.video.crf ?? 23),
        "-pix_fmt",
        "yuv420p",
        "-c:a",
        "aac",
        "-b:a",
        `${opts.profile.audio.bitrate_kbps ?? 128}k`,
        "-movflags",
        "+faststart",
        "-map_metadata",
        "0",
        "-map_chapters",
        "0",
        ...detArgs,
        output
      ],
      { maxOutputBytes: 200_000, logFilePath: opts.logFilePath }
    );
  }

  if (opts.profile.video.codec === "hevc") {
    return execLimited(
      "ffmpeg",
      [
        "-hide_banner",
        "-y",
        "-i",
        input,
        "-map",
        "0:v:0",
        "-map",
        "0:a?",
        "-map",
        "-0:d?",
        "-map",
        "-0:s?",
        "-vf",
        `scale=w=${opts.profile.video.width ?? 854}:h=${opts.profile.video.height ?? 480}:force_original_aspect_ratio=decrease,pad=${opts.profile.video.width ?? 854}:${opts.profile.video.height ?? 480}:(ow-iw)/2:(oh-ih)/2,format=yuv420p`,
        "-c:v",
        "libx265",
        "-preset",
        opts.profile.video.preset ?? "medium",
        "-crf",
        String(opts.profile.video.crf ?? 28),
        "-c:a",
        "aac",
        "-b:a",
        `${opts.profile.audio.bitrate_kbps ?? 96}k`,
        "-movflags",
        "+faststart",
        "-map_metadata",
        "0",
        "-map_chapters",
        "0",
        ...detArgs,
        output
      ],
      { maxOutputBytes: 200_000, logFilePath: opts.logFilePath }
    );
  }

  if (opts.profile.video.codec === "prores") {
    return execLimited(
      "ffmpeg",
      [
        "-hide_banner",
        "-y",
        "-i",
        input,
        "-map",
        "0:v:0",
        "-map",
        "0:a?",
        "-map",
        "-0:d?",
        "-map",
        "-0:s?",
        "-c:v",
        "prores_ks",
        "-profile:v",
        opts.profile.video.profile === "hq" ? "3" : "2",
        "-c:a",
        "pcm_s16le",
        "-map_metadata",
        "0",
        "-map_chapters",
        "0",
        ...detArgs,
        output
      ],
      { maxOutputBytes: 200_000, logFilePath: opts.logFilePath }
    );
  }

  throw new AppError("9300_validation_failed", "Unsupported profile codec", { codec: opts.profile.video.codec });
}

async function thumbnail(input: string, outJpg: string, logFilePath?: string) {
  return execLimited("ffmpeg", ["-hide_banner", "-y", "-ss", "00:00:01.000", "-i", input, "-frames:v", "1", "-vf", "scale=320:-2:flags=bicubic", outJpg], {
    maxOutputBytes: 200_000,
    logFilePath
  });
}

export async function processJob(ctx: Ctx) {
  const { prisma, jobId, attempt, logger, metrics } = ctx;
  const job = await prisma.job.findUnique({ where: { id: jobId } });
  if (!job) throw new AppError("9200_not_found", "Job not found");
  if (job.status === "canceled") return;

  await setJob(prisma, jobId, { status: "running", phase: "analyze", progress: 1, retryCount: attempt - 1 });

  const wd = workDir(ctx.repoRoot, jobId);
  fs.mkdirSync(wd, { recursive: true });
  const logDir = path.join(ctx.repoRoot, "data", "logs");
  fs.mkdirSync(logDir, { recursive: true });
  const logFilePath = path.join(logDir, `${jobId}.log`);
  let inputPath: string | null = null;
  try {
    const st = fs.statSync(logFilePath);
    if (st.size > 20 * 1024 * 1024) {
      fs.renameSync(logFilePath, `${logFilePath}.1`);
    }
  } catch {
    // ignore
  }

  try {
    const policy = loadPolicy(ctx.repoRoot);
    const profile = policy.profiles[job.profile];
    if (!profile) throw new AppError("9300_validation_failed", "Unknown profile", { profile: job.profile });

    const source = job.sourceJson as any;
    inputPath = path.join(wd, "input");

    await setJob(prisma, jobId, { phase: "fetch", progress: 5 });
    if (source.type === "upload" && source.uploadPath) {
      fs.copyFileSync(source.uploadPath, inputPath);
    } else if (source.type === "http" || source.type === "s3_signed_url") {
      await downloadToFile(source.uri, inputPath, 100 * 1024 * 1024);
    } else if (source.type === "yt_dlp") {
      const outTemplate = path.join(wd, "ytdlp.%(ext)s");
      const res = await execLimited("yt-dlp", ["-o", outTemplate, source.uri], { maxOutputBytes: 200_000, logFilePath });
      if (res.exitCode !== 0) throw new AppError("4001_drm_or_restricted_source", "yt-dlp failed", res);
      const files = fs.readdirSync(wd).filter((f) => f.startsWith("ytdlp."));
      if (files.length === 0) throw new AppError("4001_drm_or_restricted_source", "yt-dlp produced no output", res);
      fs.renameSync(path.join(wd, files[0]), inputPath);
    } else if (source.type === "stream") {
      const capture = Number(source.capture_seconds ?? 30);
      const res = await execLimited(
        "ffmpeg",
        ["-hide_banner", "-y", "-rtsp_transport", "tcp", "-i", source.uri, "-t", String(capture), "-c", "copy", inputPath],
        { maxOutputBytes: 200_000, logFilePath }
      );
      if (res.exitCode !== 0) {
        // Stream ingest is best-effort; fall back to transcode capture if copy fails.
        const res2 = await execLimited(
          "ffmpeg",
          ["-hide_banner", "-y", "-rtsp_transport", "tcp", "-i", source.uri, "-t", String(capture), "-c:v", "libx264", "-c:a", "aac", inputPath],
          { maxOutputBytes: 200_000, logFilePath }
        );
        if (res2.exitCode !== 0) throw new AppError("1000_invalid_source_uri", "Stream capture failed", { copy: res, transcode: res2 });
      }
    } else if (source.type === "zip") {
      const zipPath = path.join(wd, "input.zip");
      await downloadToFile(source.uri, zipPath, 500 * 1024 * 1024);
      const res = await execLimited("unzip", ["-o", zipPath, "-d", path.join(wd, "unzipped")], { maxOutputBytes: 200_000, logFilePath });
      if (res.exitCode !== 0) throw new AppError("9100_internal_error", "Unzip failed", res);

      const subDir = path.join(wd, "unzipped");
      const entries = fs.readdirSync(subDir);
      const videoFiles = entries.filter((f) => /\.(mp4|mov|mkv|avi|mxf|ts)$/i.test(f));
      const warnings: string[] = [];
      const q = new Queue("ingest", { connection: { url: process.env.REDIS_URL ?? "redis://localhost:6379" } });
      for (const vf of videoFiles) {
        const subJob = await prisma.job.create({
          data: {
            projectId: job.projectId,
            status: "queued",
            phase: null,
            progress: 0,
            profile: job.profile,
            randomSeed: job.randomSeed,
            sourceJson: { type: "upload", uploadPath: path.join(subDir, vf) }
          }
        });
        await q.add("ingest", { jobId: subJob.id }, { attempts: 3, backoff: { type: "exponential", delay: 5_000 } });
        warnings.push(`Created subjob ${subJob.id} for ${vf}`);
      }
      await setJob(prisma, jobId, { status: "partial_success", phase: null, progress: 100, warningsJson: warnings });
      metrics.jobsTotal.inc({ status: "partial_success" });
      return;
    } else {
      throw new AppError("1000_invalid_source_uri", "Unsupported source type", source);
    }

    if (await isCanceled(prisma, jobId)) return;

    if (isZipFile(inputPath)) {
      const zipPath = path.join(wd, "input.zip");
      fs.renameSync(inputPath, zipPath);
      const res = await execLimited("unzip", ["-o", zipPath, "-d", path.join(wd, "unzipped")], { maxOutputBytes: 200_000, logFilePath });
      if (res.exitCode !== 0) throw new AppError("9100_internal_error", "Unzip failed", res);
      const subDir = path.join(wd, "unzipped");
      const entries = fs.readdirSync(subDir);
      const videoFiles = entries.filter((f) => /\.(mp4|mov|mkv|avi|mxf|ts)$/i.test(f));
      const warnings: string[] = [];
      const q = new Queue("ingest", { connection: { url: process.env.REDIS_URL ?? "redis://localhost:6379" } });
      for (const vf of videoFiles) {
        const subJob = await prisma.job.create({
          data: {
            projectId: job.projectId,
            status: "queued",
            phase: null,
            progress: 0,
            profile: job.profile,
            randomSeed: job.randomSeed,
            sourceJson: { type: "upload", uploadPath: path.join(subDir, vf) }
          }
        });
        await q.add("ingest", { jobId: subJob.id }, { attempts: 3, backoff: { type: "exponential", delay: 5_000 } });
        warnings.push(`Created subjob ${subJob.id} for ${vf}`);
      }
      await setJob(prisma, jobId, { status: "partial_success", phase: null, progress: 100, warningsJson: warnings });
      metrics.jobsTotal.inc({ status: "partial_success" });
      return;
    }

    if (await isCanceled(prisma, jobId)) return;

    await setJob(prisma, jobId, { phase: "analyze", progress: 10 });
    const probeRes = await ffprobeFast(inputPath);
    if (probeRes.exitCode !== 0) throw new AppError("2001_ffprobe_failed", "ffprobe failed", probeRes);

    let probeJson: any;
    try {
      probeJson = JSON.parse(probeRes.stdout);
    } catch {
      throw new AppError("2001_ffprobe_failed", "ffprobe output not JSON", { stdout: probeRes.stdout, stderr: probeRes.stderr });
    }

    const duration = Number(probeJson?.format?.duration);
    if (!Number.isFinite(duration) || duration <= 0) {
      const frameTest = await execLimited("ffmpeg", ["-hide_banner", "-y", "-v", "error", "-i", inputPath, "-frames:v", "1", "-f", "null", "-"], {
        maxOutputBytes: 50_000,
        logFilePath
      });
      if (frameTest.exitCode !== 0) {
        throw new AppError("1003_short_probe", "No duration and frame decode failed", { ffprobe: probeJson?.format, ffmpeg: frameTest });
      }
      probeJson.format = { ...(probeJson.format ?? {}), duration: "1.0" };
    }

    const plan = buildPlanFromProbe(probeJson, profile, { workerGpu: ctx.workerGpu });
    await setJob(prisma, jobId, { planJson: plan, phase: "scan", progress: 20, warningsJson: plan.warnings });

    await clamavScan(inputPath, logFilePath);

    if (await isCanceled(prisma, jobId)) return;

    const outVideo = path.join(wd, profile.container === "mp4" ? "output.mp4" : "output.mov");
    const outThumb = path.join(wd, "thumb.jpg");

    // corruption pre-pass best effort
    await execLimited("ffmpeg", ["-hide_banner", "-y", "-err_detect", "ignore_err", "-fflags", "+discardcorrupt", "-i", inputPath, "-map", "0", "-c", "copy", "-f", "null", "-"], {
      maxOutputBytes: 50_000,
      logFilePath
    }).catch(() => undefined);

    const transcodeStart = Date.now();
    const step = plan.steps.find((s) => s.kind === "remux" || s.kind === "transcode");
    if (!step) throw new AppError("9100_internal_error", "Plan missing encode step", plan);

    if (step.kind === "remux") {
      await setJob(prisma, jobId, { phase: "remux", progress: 40 });
      const res = await ffmpegRemux(inputPath, outVideo, logFilePath);
      if (res.exitCode !== 0) throw new AppError("3001_transcode_failed", "Remux failed", res);
    } else {
      await setJob(prisma, jobId, { phase: "transcode", progress: 40 });
      const useHw = attempt === 1 ? Boolean(step.useHw) : false;
      const effectiveProfile = {
        ...profile,
        video: {
          ...profile.video,
          preset: attempt === 1 ? profile.video.preset : "faster",
          crf: attempt === 1 ? profile.video.crf : (profile.video.crf ?? 23) + 2
        }
      };
      const res = await ffmpegTranscode(inputPath, outVideo, { profile: effectiveProfile, useHw, deterministic: plan.deterministic, logFilePath });
      metrics.ffmpegErrorCodesTotal.inc({ code: String(res.exitCode ?? -1) });
      if (res.exitCode !== 0) throw new AppError("3001_transcode_failed", "Transcode failed", res);
    }
    metrics.avgTranscodeTime.observe((Date.now() - transcodeStart) / 1000);

    await setJob(prisma, jobId, { phase: "package", progress: 80 });
    const thumbRes = await thumbnail(outVideo, outThumb, logFilePath);
    if (thumbRes.exitCode !== 0) throw new AppError("3001_transcode_failed", "Thumbnail failed", thumbRes);

    const s3 = createS3({
      endPoint: process.env.S3_ENDPOINT ?? "http://localhost:9000",
      region: process.env.S3_REGION ?? "us-east-1",
      accessKey: process.env.S3_ACCESS_KEY ?? "minio",
      secretKey: process.env.S3_SECRET_KEY ?? "minio123",
      bucket: process.env.S3_BUCKET ?? "artifacts"
    });
    const videoKey = `jobs/${jobId}/output${profile.container === "mp4" ? ".mp4" : ".mov"}`;
    const thumbKey = `jobs/${jobId}/thumb.jpg`;

    const [videoPut, thumbPut] = await Promise.all([
      s3.putFile({ key: videoKey, filePath: outVideo, contentType: profile.container === "mp4" ? "video/mp4" : "video/quicktime" }),
      s3.putFile({ key: thumbKey, filePath: outThumb, contentType: "image/jpeg" })
    ]);

    const [videoSha, thumbSha] = await Promise.all([sha256File(outVideo), sha256File(outThumb)]);

    await prisma.artifact.createMany({
      data: [
        {
          jobId,
          kind: "video",
          bucket: s3.bucket,
          key: videoKey,
          contentType: profile.container === "mp4" ? "video/mp4" : "video/quicktime",
          bytes: videoPut.bytes,
          sha256: videoSha
        },
        {
          jobId,
          kind: "thumbnail",
          bucket: s3.bucket,
          key: thumbKey,
          contentType: "image/jpeg",
          bytes: thumbPut.bytes,
          sha256: thumbSha
        }
      ]
    });

    const rate = Number(process.env.QA_SAMPLING_RATE ?? "0.01");
    if (shouldSample(jobId, rate)) {
      const date = new Date().toISOString().slice(0, 10);
      const qaKey = `qa-samples/${date}/${jobId}/output${profile.container === "mp4" ? ".mp4" : ".mov"}`;
      const put = await s3.putFile({
        key: qaKey,
        filePath: outVideo,
        contentType: profile.container === "mp4" ? "video/mp4" : "video/quicktime"
      });
      const sha = await sha256File(outVideo);
      await prisma.artifact.create({
        data: {
          jobId,
          kind: "qa_sample",
          bucket: s3.bucket,
          key: qaKey,
          contentType: profile.container === "mp4" ? "video/mp4" : "video/quicktime",
          bytes: put.bytes,
          sha256: sha
        }
      });
    }

    await setJob(prisma, jobId, { status: "succeeded", phase: null, progress: 100 });
    metrics.jobsTotal.inc({ status: "succeeded" });
    metrics.jobsSuccess.inc();
  } catch (err) {
    const appErr = err instanceof AppError ? err : new AppError("9100_internal_error", "Internal error", { err: String(err) });
    logger.error({ job_id: jobId, code: appErr.code, details: appErr.details }, "job_error");
    if (appErr.code === "5001_rejected_malware") {
      await setJob(prisma, jobId, {
        status: "rejected_malware",
        phase: null,
        progress: 0,
        errorCode: appErr.code,
        errorMessage: appErr.message,
        errorDetails: { remediation: appErr.remediation, details: appErr.details }
      });
      metrics.jobsTotal.inc({ status: "rejected_malware" });
      metrics.jobsFailed.inc();
      return;
    }

    const finalAttempt = attempt >= 3;

    if (finalAttempt && inputPath) {
      try {
        const debugDir = path.join(wd, "debug");
        fs.mkdirSync(debugDir, { recursive: true });
        await execLimited("ffmpeg", ["-hide_banner", "-y", "-i", inputPath, "-frames:v", "10", path.join(debugDir, "frame_%03d.jpg")], { maxOutputBytes: 50_000, logFilePath });
        const tarPath = path.join(wd, "debug_bundle.tar.gz");
        await execLimited("tar", ["-czf", tarPath, "-C", wd, "debug"], { maxOutputBytes: 50_000, logFilePath });

        const s3 = createS3({
          endPoint: process.env.S3_ENDPOINT ?? "http://localhost:9000",
          region: process.env.S3_REGION ?? "us-east-1",
          accessKey: process.env.S3_ACCESS_KEY ?? "minio",
          secretKey: process.env.S3_SECRET_KEY ?? "minio123",
          bucket: process.env.S3_BUCKET ?? "artifacts"
        });
        const debugKey = `jobs/${jobId}/debug_bundle.tar.gz`;
        const put = await s3.putFile({ key: debugKey, filePath: tarPath, contentType: "application/gzip" });
        const sha = await sha256File(tarPath);
        await prisma.artifact.create({
          data: {
            jobId,
            kind: "debug_bundle",
            bucket: s3.bucket,
            key: debugKey,
            contentType: "application/gzip",
            bytes: put.bytes,
            sha256: sha
          }
        });
      } catch (e) {
        logger.warn({ job_id: jobId, err: e }, "debug_bundle_failed");
      }
    }

    await setJob(prisma, jobId, {
      status: finalAttempt ? "failed_escalation" : "failed",
      phase: null,
      progress: 0,
      errorCode: finalAttempt ? "9000_manual_inspection_required" : appErr.code,
      errorMessage: appErr.message,
      errorDetails: { remediation: appErr.remediation, details: appErr.details }
    });
    metrics.jobsTotal.inc({ status: finalAttempt ? "failed_escalation" : "failed" });
    metrics.jobsFailed.inc();
    throw err;
  }
}
