import "dotenv/config";
import { NestFactory } from "@nestjs/core";
import { SwaggerModule, DocumentBuilder } from "@nestjs/swagger";
import helmet from "helmet";
import { json, raw } from "express";
import { AppModule } from "./modules/app.module";
import { initOtel } from "@video/observability";
import { createLogger } from "@video/observability";
import { AppErrorFilter } from "./modules/common/error.filter";
import pinoHttp from "pino-http";

async function bootstrap() {
  await initOtel("api");
  const logger = createLogger({ service: "api" });
  const app = await NestFactory.create(AppModule, { logger: false });

  app.use(helmet());
  app.use(pinoHttp({ logger }));
  app.use(json({ limit: "2mb" }));
  app.use("/api/v1/sessions/:id/upload_chunk", raw({ type: "application/octet-stream", limit: "250mb" }));
  app.useGlobalFilters(new AppErrorFilter(logger));

  const config = new DocumentBuilder()
    .setTitle("Video Ingest API")
    .setVersion("1.0.0")
    .addBearerAuth()
    .build();
  const doc = SwaggerModule.createDocument(app, config);
  SwaggerModule.setup("docs", app, doc);

  const port = Number(process.env.PORT ?? 8080);
  await app.listen(port, "0.0.0.0");
  logger.info({ port }, "api_listening");
}

void bootstrap();
