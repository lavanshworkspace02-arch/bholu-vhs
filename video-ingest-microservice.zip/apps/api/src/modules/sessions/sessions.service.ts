import fs from "node:fs";
import path from "node:path";
import { Injectable } from "@nestjs/common";
import { PrismaService } from "../common/prisma.service";
import { QueueService } from "../common/queue.service";
import { AppError, SourceSchema } from "@video/shared";
import { v4 as uuidv4 } from "uuid";
import { loadPolicy } from "@video/shared";
import { ffprobeFast, buildPlanFromProbe } from "@video/ffmpeg";

function repoRoot() {
  return process.env.REPO_ROOT ?? process.cwd();
}

function parseContentRange(v: string) {
  // bytes start-end/total
  const m = /^bytes (\d+)-(\d+)\/(\d+)$/.exec(v);
  if (!m) throw new AppError("9300_validation_failed", "Invalid Content-Range format", { header: v });
  const start = Number(m[1]);
  const end = Number(m[2]);
  const total = Number(m[3]);
  if (!(start >= 0 && end >= start && total > 0 && end < total)) {
    throw new AppError("9300_validation_failed", "Invalid Content-Range numbers", { start, end, total });
  }
  return { start, end, total, length: end - start + 1 };
}

@Injectable()
export class SessionsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly queue: QueueService
  ) {}

  async ensureDefaultProject(userId: string) {
    const user = await this.prisma.client.user.upsert({
      where: { email: `${userId}@local` },
      update: {},
      create: { email: `${userId}@local` }
    });
    const project = await this.prisma.client.project.findFirst({ where: { ownerId: user.id, name: "default" } });
    if (project) return project;
    return this.prisma.client.project.create({ data: { ownerId: user.id, name: "default" } });
  }

  async createSession(opts: { userId: string; projectId?: string; profile: string; randomSeed?: string; source: unknown }) {
    const policy = loadPolicy(repoRoot());
    if (!policy.profiles[opts.profile]) throw new AppError("9300_validation_failed", "Unknown profile", { profile: opts.profile });

    const parsedSource = SourceSchema.safeParse(opts.source);
    if (!parsedSource.success) {
      throw new AppError("1000_invalid_source_uri", "Unsupported source payload", parsedSource.error.flatten());
    }

    const project = opts.projectId
      ? await this.prisma.client.project.findUnique({ where: { id: opts.projectId } })
      : await this.ensureDefaultProject(opts.userId);
    if (!project) throw new AppError("9200_not_found", "Project not found");

    const id = uuidv4();
    const uploadPath = parsedSource.data.type === "upload" ? path.join(repoRoot(), "data", "intake", `${id}.bin`) : null;
    if (uploadPath) fs.mkdirSync(path.dirname(uploadPath), { recursive: true });

    const session = await this.prisma.client.intakeSession.create({
      data: {
        id,
        projectId: project.id,
        status: "open",
        profile: opts.profile,
        randomSeed: opts.randomSeed ?? null,
        sourceJson: parsedSource.data,
        uploadPath: uploadPath ?? undefined
      }
    });

    return {
      id: session.id,
      status: session.status,
      profile: session.profile,
      source: session.sourceJson,
      upload: uploadPath
        ? {
            upload_chunk_url: `/api/v1/sessions/${session.id}/upload_chunk`,
            commit_url: `/api/v1/sessions/${session.id}/commit`
          }
        : undefined
    };
  }

  async uploadChunk(opts: { sessionId: string; contentRange: string; bytes: Buffer }) {
    const session = await this.prisma.client.intakeSession.findUnique({ where: { id: opts.sessionId } });
    if (!session) throw new AppError("9200_not_found", "Session not found");
    if (session.status !== "open") throw new AppError("9300_validation_failed", "Session is not open");
    const source = SourceSchema.parse(session.sourceJson);
    if (source.type !== "upload") throw new AppError("9300_validation_failed", "Session is not an upload session");
    if (!session.uploadPath) throw new AppError("9100_internal_error", "Missing uploadPath");

    const cr = parseContentRange(opts.contentRange);
    if (opts.bytes.length !== cr.length) {
      throw new AppError("9300_validation_failed", "Chunk length does not match Content-Range", { expected: cr.length, got: opts.bytes.length });
    }

    const uploadedBytes = Number(session.uploadedBytes);
    if (cr.start !== uploadedBytes) {
      throw new AppError("9300_validation_failed", "Chunk offset mismatch", { expected_start: uploadedBytes, got_start: cr.start });
    }

    const fd = fs.openSync(session.uploadPath, "a");
    try {
      fs.writeSync(fd, opts.bytes, 0, opts.bytes.length, cr.start);
    } finally {
      fs.closeSync(fd);
    }

    const next = cr.end + 1;
    await this.prisma.client.intakeSession.update({
      where: { id: session.id },
      data: {
        uploadedBytes: BigInt(next),
        totalBytes: BigInt(cr.total)
      }
    });

    return { received: opts.bytes.length, next_offset: next, total: cr.total, complete: next === cr.total };
  }

  async uploadWhole(opts: { sessionId: string; bytes: Buffer }) {
    const session = await this.prisma.client.intakeSession.findUnique({ where: { id: opts.sessionId } });
    if (!session) throw new AppError("9200_not_found", "Session not found");
    if (session.status !== "open") throw new AppError("9300_validation_failed", "Session is not open");
    const source = SourceSchema.parse(session.sourceJson);
    if (source.type !== "upload") throw new AppError("9300_validation_failed", "Session is not an upload session");
    if (!session.uploadPath) throw new AppError("9100_internal_error", "Missing uploadPath");
    if (Number(session.uploadedBytes) !== 0) throw new AppError("9300_validation_failed", "Session already has uploaded bytes; use upload_chunk to resume");

    fs.mkdirSync(path.dirname(session.uploadPath), { recursive: true });
    fs.writeFileSync(session.uploadPath, opts.bytes);

    await this.prisma.client.intakeSession.update({
      where: { id: session.id },
      data: {
        uploadedBytes: BigInt(opts.bytes.length),
        totalBytes: BigInt(opts.bytes.length)
      }
    });

    return { received: opts.bytes.length, next_offset: opts.bytes.length, total: opts.bytes.length, complete: true };
  }

  async commit(opts: { userId: string; sessionId: string }) {
    const session = await this.prisma.client.intakeSession.findUnique({ where: { id: opts.sessionId } });
    if (!session) throw new AppError("9200_not_found", "Session not found");
    if (session.status !== "open") throw new AppError("9300_validation_failed", "Session is not open");
    const source = SourceSchema.parse(session.sourceJson);
    if (source.type === "upload") {
      const total = session.totalBytes ? Number(session.totalBytes) : null;
      if (!total || Number(session.uploadedBytes) !== total) {
        throw new AppError("9300_validation_failed", "Upload incomplete", { uploaded: session.uploadedBytes.toString(), total: session.totalBytes?.toString() });
      }
    }

    await this.prisma.client.intakeSession.update({ where: { id: session.id }, data: { status: "committed" } });

    const job = await this.prisma.client.job.create({
      data: {
        projectId: session.projectId,
        status: "queued",
        phase: null,
        progress: 0,
        profile: session.profile,
        randomSeed: session.randomSeed,
        sourceJson:
          source.type === "upload"
            ? { type: "upload", uploadPath: session.uploadPath }
            : source
      }
    });

    // Commit-time fast probe for uploads (matches required logic).
    if (source.type === "upload" && session.uploadPath) {
      const policy = loadPolicy(repoRoot());
      const profile = policy.profiles[session.profile];
      const probeRes = await ffprobeFast(session.uploadPath);
      if (probeRes.exitCode !== 0) {
        await this.prisma.client.job.update({
          where: { id: job.id },
          data: {
            status: "failed",
            errorCode: "2001_ffprobe_failed",
            errorMessage: "ffprobe failed",
            errorDetails: probeRes
          }
        });
        return { job_id: job.id, status: "failed", error_code: "2001_ffprobe_failed" };
      }
      let probeJson: any;
      try {
        probeJson = JSON.parse(probeRes.stdout);
      } catch {
        await this.prisma.client.job.update({
          where: { id: job.id },
          data: {
            status: "failed",
            errorCode: "2001_ffprobe_failed",
            errorMessage: "ffprobe output not JSON",
            errorDetails: { stdout: probeRes.stdout, stderr: probeRes.stderr }
          }
        });
        return { job_id: job.id, status: "failed", error_code: "2001_ffprobe_failed" };
      }
      const plan = buildPlanFromProbe(probeJson, profile as any, { workerGpu: false });
      await this.prisma.client.job.update({ where: { id: job.id }, data: { planJson: plan, warningsJson: plan.warnings } });
    }

    await this.queue.enqueueIngest(job.id);
    return { job_id: job.id, status_url: `/api/v1/jobs/${job.id}/status` };
  }

  async getSession(id: string) {
    const s = await this.prisma.client.intakeSession.findUnique({ where: { id } });
    if (!s) throw new AppError("9200_not_found", "Session not found");
    return {
      id: s.id,
      status: s.status,
      profile: s.profile,
      uploaded_bytes: s.uploadedBytes.toString(),
      total_bytes: s.totalBytes?.toString() ?? null
    };
  }
}
