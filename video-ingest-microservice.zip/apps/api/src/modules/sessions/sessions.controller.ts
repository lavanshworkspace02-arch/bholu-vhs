import {
  Body,
  Controller,
  Get,
  Param,
  Post,
  Req,
  UploadedFile,
  UseInterceptors,
  UseGuards
} from "@nestjs/common";
import type { Request } from "express";
import { ApiBearerAuth, ApiTags } from "@nestjs/swagger";
import { SessionsService } from "./sessions.service";
import { AuthGuard } from "../common/auth.guard";
import { AppError } from "@video/shared";
import { FileInterceptor } from "@nestjs/platform-express";

type CreateSessionBody = {
  project_id?: string;
  profile: string;
  random_seed?: string;
  source: any;
};

@ApiTags("sessions")
@ApiBearerAuth()
@Controller("/api/v1/sessions")
export class SessionsController {
  constructor(private readonly sessions: SessionsService) {}

  @UseGuards(AuthGuard)
  @Post()
  async create(@Req() req: Request, @Body() body: CreateSessionBody) {
    const userId = (req as any).user?.userId as string;
    if (!body?.profile) throw new AppError("9300_validation_failed", "profile is required");
    return this.sessions.createSession({ userId, projectId: body.project_id, profile: body.profile, randomSeed: body.random_seed, source: body.source });
  }

  @UseGuards(AuthGuard)
  @Post("/:id/upload_chunk")
  async uploadChunk(@Param("id") id: string, @Req() req: Request) {
    const contentRange = req.header("content-range");
    if (!contentRange) throw new AppError("9300_validation_failed", "Content-Range header is required");
    const buf = (req as any).body as Buffer;
    if (!Buffer.isBuffer(buf) || buf.length === 0) throw new AppError("9300_validation_failed", "Binary body required");
    return this.sessions.uploadChunk({ sessionId: id, contentRange, bytes: buf });
  }

  @UseGuards(AuthGuard)
  @Post("/:id/upload")
  @UseInterceptors(FileInterceptor("file", { limits: { fileSize: 250 * 1024 * 1024 } }))
  async uploadMultipart(@Param("id") id: string, @UploadedFile() file?: Express.Multer.File) {
    if (!file?.buffer) throw new AppError("9300_validation_failed", "file is required");
    return this.sessions.uploadWhole({ sessionId: id, bytes: file.buffer });
  }

  @UseGuards(AuthGuard)
  @Post("/:id/commit")
  async commit(@Req() req: Request, @Param("id") id: string) {
    const userId = (req as any).user?.userId as string;
    return this.sessions.commit({ userId, sessionId: id });
  }

  @UseGuards(AuthGuard)
  @Get("/:id")
  async get(@Param("id") id: string) {
    return this.sessions.getSession(id);
  }
}
