import { Controller, Get, Param, Post, Req, UseGuards } from "@nestjs/common";
import type { Request } from "express";
import { ApiBearerAuth, ApiTags } from "@nestjs/swagger";
import { AuthGuard } from "../common/auth.guard";
import { JobsService } from "./jobs.service";

@ApiTags("jobs")
@ApiBearerAuth()
@Controller("/api/v1/jobs")
export class JobsController {
  constructor(private readonly jobs: JobsService) {}

  @UseGuards(AuthGuard)
  @Get("/:id/status")
  async status(@Param("id") id: string) {
    return this.jobs.status(id);
  }

  @UseGuards(AuthGuard)
  @Post("/:id/cancel")
  async cancel(@Req() req: Request, @Param("id") id: string) {
    const userId = (req as any).user?.userId as string;
    return this.jobs.cancel({ userId, jobId: id });
  }
}

