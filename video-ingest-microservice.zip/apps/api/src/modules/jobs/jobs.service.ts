import { Injectable } from "@nestjs/common";
import { PrismaService } from "../common/prisma.service";
import { QueueService } from "../common/queue.service";
import { StorageService } from "../common/storage.service";
import { AppError } from "@video/shared";

@Injectable()
export class JobsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly queue: QueueService,
    private readonly storage: StorageService
  ) {}

  async status(jobId: string) {
    const job = await this.prisma.client.job.findUnique({ where: { id: jobId }, include: { artifacts: true } });
    if (!job) throw new AppError("9200_not_found", "Job not found");
    const artifacts = await Promise.all(
      job.artifacts.map(async (a) => ({
        id: a.id,
        kind: a.kind,
        sha256: a.sha256,
        bytes: a.bytes.toString(),
        url: await this.storage.presign(a.key, 3600)
      }))
    );
    return {
      id: job.id,
      status: job.status,
      phase: job.phase,
      progress: job.progress,
      profile: job.profile,
      random_seed: job.randomSeed,
      plan: job.planJson,
      warnings: job.warningsJson ?? [],
      error:
        job.errorCode
          ? {
              error_code: job.errorCode,
              message: job.errorMessage,
              details: job.errorDetails
            }
          : null,
      artifacts
    };
  }

  async cancel(opts: { userId: string; jobId: string }) {
    const job = await this.prisma.client.job.findUnique({ where: { id: opts.jobId } });
    if (!job) throw new AppError("9200_not_found", "Job not found");
    await this.queue.cancel(job.id);
    await this.prisma.client.job.update({ where: { id: job.id }, data: { status: "canceled", phase: null, progress: 0 } });
    return { id: job.id, status: "canceled" };
  }
}
