import path from "node:path";
import { Controller, Get } from "@nestjs/common";
import { ApiTags } from "@nestjs/swagger";
import { loadPolicy } from "@video/shared";

function repoRoot() {
  return process.env.REPO_ROOT ?? process.cwd();
}

@ApiTags("presets")
@Controller("/api/v1/presets")
export class PresetsController {
  @Get()
  async list() {
    const policy = loadPolicy(repoRoot());
    return { version: policy.version, profiles: policy.profiles };
  }
}
