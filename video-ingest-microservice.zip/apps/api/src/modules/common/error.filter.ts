import type { ArgumentsHost, ExceptionFilter } from "@nestjs/common";
import { Catch, HttpStatus } from "@nestjs/common";
import type { Logger } from "pino";
import { AppError, ErrorRemediation } from "@video/shared";

@Catch()
export class AppErrorFilter implements ExceptionFilter {
  constructor(private readonly logger: Logger) {}

  catch(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const res = ctx.getResponse() as { status: (n: number) => any; json: (b: any) => any };

    if (exception instanceof AppError) {
      const status =
        exception.code === "9300_validation_failed"
          ? HttpStatus.BAD_REQUEST
          : exception.code === "9200_not_found"
            ? HttpStatus.NOT_FOUND
            : HttpStatus.UNPROCESSABLE_ENTITY;
      return res.status(status).json({
        error_code: exception.code,
        message: exception.message,
        remediation: exception.remediation,
        details: exception.details
      });
    }

    this.logger.error({ err: exception }, "unhandled_exception");
    return res.status(HttpStatus.INTERNAL_SERVER_ERROR).json({
      error_code: "9100_internal_error",
      message: "Internal error",
      remediation: ErrorRemediation["9100_internal_error"]
    });
  }
}

