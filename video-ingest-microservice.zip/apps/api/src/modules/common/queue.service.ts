import { Injectable } from "@nestjs/common";
import { Queue } from "bullmq";

@Injectable()
export class QueueService {
  private readonly queue: Queue;

  constructor() {
    const connection = { url: process.env.REDIS_URL ?? "redis://localhost:6379" };
    this.queue = new Queue("ingest", { connection });
  }

  async enqueueIngest(jobId: string) {
    await this.queue.add(
      "ingest",
      { jobId },
      {
        attempts: 3,
        backoff: { type: "exponential", delay: 5_000 },
        removeOnComplete: 1000,
        removeOnFail: 1000
      }
    );
  }

  async cancel(jobId: string) {
    const job = await this.queue.getJob(jobId);
    if (job) await job.remove().catch(() => undefined);
  }
}

