import { Global, Module } from "@nestjs/common";
import { PrismaService } from "./prisma.service";
import { AuthGuard } from "./auth.guard";
import { QueueService } from "./queue.service";
import { MetricsController } from "./metrics.controller";
import { MetricsService } from "./metrics.service";
import { StorageService } from "./storage.service";

@Global()
@Module({
  providers: [PrismaService, AuthGuard, QueueService, MetricsService, StorageService],
  controllers: [MetricsController],
  exports: [PrismaService, AuthGuard, QueueService, MetricsService, StorageService]
})
export class CommonModule {}

