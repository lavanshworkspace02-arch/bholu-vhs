import type { CanActivate, ExecutionContext } from "@nestjs/common";
import { Injectable } from "@nestjs/common";
import jwt from "jsonwebtoken";

export type RequestUser = { userId: string };

@Injectable()
export class AuthGuard implements CanActivate {
  canActivate(ctx: ExecutionContext): boolean {
    const req = ctx.switchToHttp().getRequest() as { headers: Record<string, string | undefined>; user?: RequestUser };

    if (process.env.ALLOW_ANON === "true") {
      req.user = { userId: "dev-user" };
      return true;
    }

    const auth = req.headers["authorization"];
    if (!auth?.startsWith("Bearer ")) return false;
    const token = auth.slice("Bearer ".length);
    const secret = process.env.JWT_SECRET ?? "";
    const payload = jwt.verify(token, secret) as { sub?: string };
    if (!payload.sub) return false;
    req.user = { userId: payload.sub };
    return true;
  }
}

