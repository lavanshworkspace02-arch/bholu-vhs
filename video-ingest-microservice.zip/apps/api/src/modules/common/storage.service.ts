import { Injectable } from "@nestjs/common";
import { createS3 } from "@video/storage";

@Injectable()
export class StorageService {
  private readonly s3 = createS3({
    endPoint: process.env.S3_ENDPOINT ?? "http://localhost:9000",
    region: process.env.S3_REGION ?? "us-east-1",
    accessKey: process.env.S3_ACCESS_KEY ?? "minio",
    secretKey: process.env.S3_SECRET_KEY ?? "minio123",
    bucket: process.env.S3_BUCKET ?? "artifacts"
  });

  async presign(key: string, ttlSeconds = 3600) {
    return this.s3.presignGetObject(key, ttlSeconds);
  }
}

