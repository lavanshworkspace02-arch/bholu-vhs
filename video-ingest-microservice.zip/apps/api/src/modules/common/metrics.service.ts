import { Injectable } from "@nestjs/common";
import client from "prom-client";
import { createRegistry } from "@video/observability";

@Injectable()
export class MetricsService {
  public readonly registry = createRegistry("api");
  public readonly httpRequestsTotal: client.Counter<string>;

  constructor() {
    this.httpRequestsTotal = new client.Counter({
      name: "http_requests_total",
      help: "Total HTTP requests",
      labelNames: ["method", "route", "status"] as const,
      registers: [this.registry]
    });
  }
}

