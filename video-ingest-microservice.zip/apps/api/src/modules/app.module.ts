import { Module } from "@nestjs/common";
import { ThrottlerModule } from "@nestjs/throttler";
import { ThrottlerGuard } from "@nestjs/throttler";
import { APP_GUARD } from "@nestjs/core";
import { CommonModule } from "./common/common.module";
import { SessionsModule } from "./sessions/sessions.module";
import { JobsModule } from "./jobs/jobs.module";
import { PresetsModule } from "./presets/presets.module";

@Module({
  imports: [
    CommonModule,
    ThrottlerModule.forRoot([
      {
        ttl: 60_000,
        limit: 60
      }
    ]),
    SessionsModule,
    JobsModule,
    PresetsModule
  ],
  providers: [{ provide: APP_GUARD, useClass: ThrottlerGuard }]
})
export class AppModule {}
